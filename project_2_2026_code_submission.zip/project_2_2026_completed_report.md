# Project 2 Report

Name: Wang Sichen (please verify)
Student ID: TODO

## Summary
The final CIFAR-10 model is `gelu_label_smooth_adamw`, trained for 8 epochs on all 50,000 training images. It achieves test accuracy 81.23% and test error 18.77%.

## Deliverable Links
- Code: local `codes/` directory. Upload it to GitHub before final submission.
- Dataset: local `cifar-10-batches-py/`; official dataset page https://www.cs.toronto.edu/~kriz/cifar.html.
- Best model weights: `outputs/cifar_training_best/models/gelu_label_smooth_adamw.pt`. Upload this file to Netdisk/Google Drive before final submission.

## CIFAR-10 Configuration Comparison
| Model | Parameters | Activation | Loss | Optimizer | Best accuracy | Test error |
| --- | ---: | --- | --- | --- | ---: | ---: |
| baseline_width32_relu_adam | 323,050 | relu | cross_entropy | adam | 69.30% | 30.70% |
| wider_width48_relu_adam | 697,434 | relu | cross_entropy | adam | 72.19% | 27.81% |
| gelu_label_smooth_adamw | 697,434 | gelu | label_smoothing | adamw | 72.88% | 27.12% |
| relu_sgd_momentum | 697,434 | relu | cross_entropy | sgd | 72.30% | 27.70% |

## Batch Normalization Comparison
VGG-A without BN: best validation accuracy 44.10%.
VGG-A with BN: best validation accuracy 57.85%.
Average gradient-spread proxy: VGG-A 0.0422, VGG-A + BN 0.0298.