"""Generate the completed Project 2 report from experiment outputs."""

import json
import os
import textwrap
from pathlib import Path

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image


ROOT = Path(__file__).resolve().parent
REPORT_DIR = ROOT / "outputs" / "report"
PDF_PATH = ROOT / "project_2_2026_completed_report.pdf"
MD_PATH = ROOT / "project_2_2026_completed_report.md"


def load_json(path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def pct(value):
    return f"{100 * value:.2f}%"


def rel(path):
    return str(Path(path)).replace("\\", "/")


def plot_gradient_variation():
    bn_root = ROOT / "outputs" / "bn_landscape"
    groups = {
        "VGG-A": sorted(bn_root.glob("vgg_a_lr_*_grad_norms.txt")),
        "VGG-A + BN": sorted(bn_root.glob("vgg_a_batchnorm_lr_*_grad_norms.txt")),
    }
    curves = {}
    for name, files in groups.items():
        loaded = [np.loadtxt(file) for file in files]
        min_len = min(len(item) for item in loaded)
        stacked = np.stack([item[:min_len] for item in loaded])
        curves[name] = {
            "mean": stacked.mean(axis=0),
            "spread": stacked.max(axis=0) - stacked.min(axis=0),
            "avg_spread": float((stacked.max(axis=0) - stacked.min(axis=0)).mean()),
        }

    output_path = REPORT_DIR / "gradient_variation_comparison.png"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    steps = np.arange(len(next(iter(curves.values()))["mean"]))
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for name, data in curves.items():
        axes[0].plot(steps, data["mean"], linewidth=1.4, label=name)
        axes[1].plot(steps, data["spread"], linewidth=1.4, label=name)
    axes[0].set_title("Mean gradient norm")
    axes[0].set_xlabel("Optimization step")
    axes[0].set_ylabel("Norm")
    axes[0].grid(alpha=0.25)
    axes[1].set_title("Max-min gradient norm across learning rates")
    axes[1].set_xlabel("Optimization step")
    axes[1].set_ylabel("Spread")
    axes[1].grid(alpha=0.25)
    axes[1].legend()
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)
    return output_path, curves


class PdfWriter:
    def __init__(self, pdf):
        self.pdf = pdf
        self.fig = None
        self.y = None
        self.page_no = 0

    def new_page(self):
        if self.fig is not None:
            self.fig.text(0.5, 0.03, f"{self.page_no}", ha="center", fontsize=8, color="#555555")
            self.pdf.savefig(self.fig)
            plt.close(self.fig)
        self.page_no += 1
        self.fig = plt.figure(figsize=(8.27, 11.69))
        self.y = 0.94

    def heading(self, text, size=16):
        if self.y < 0.12:
            self.new_page()
        self.fig.text(0.08, self.y, text, fontsize=size, weight="bold", va="top")
        self.y -= 0.045

    def paragraph(self, text, size=10, width=92):
        for line in textwrap.wrap(text, width=width):
            if self.y < 0.08:
                self.new_page()
            self.fig.text(0.08, self.y, line, fontsize=size, va="top")
            self.y -= 0.022
        self.y -= 0.012

    def bullet(self, text):
        self.paragraph("- " + text, size=9.5, width=95)

    def table(self, columns, rows, col_widths=None, font_size=8):
        height = 0.06 + 0.034 * len(rows)
        if self.y - height < 0.08:
            self.new_page()
        ax = self.fig.add_axes([0.08, self.y - height, 0.84, height])
        ax.axis("off")
        table = ax.table(cellText=rows, colLabels=columns, cellLoc="left", loc="center",
                         colWidths=col_widths)
        table.auto_set_font_size(False)
        table.set_fontsize(font_size)
        table.scale(1, 1.25)
        for (row, _col), cell in table.get_celld().items():
            cell.set_edgecolor("#d0d0d0")
            if row == 0:
                cell.set_facecolor("#f0f0f0")
                cell.set_text_props(weight="bold")
        self.y -= height + 0.02

    def image_page(self, title, image_path, caption):
        self.new_page()
        self.heading(title)
        img = Image.open(image_path)
        ax = self.fig.add_axes([0.08, 0.20, 0.84, 0.62])
        ax.imshow(img)
        ax.axis("off")
        self.fig.text(0.08, 0.16, caption, fontsize=9.5, va="top")
        self.y = 0.12

    def close(self):
        if self.fig is not None:
            self.fig.text(0.5, 0.03, f"{self.page_no}", ha="center", fontsize=8, color="#555555")
            self.pdf.savefig(self.fig)
            plt.close(self.fig)
            self.fig = None


def build_markdown(cifar_cmp, cifar_best, bn, grad_summary):
    best = cifar_best["results"][0]
    bn_no = bn["models"]["vgg_a"]
    bn_yes = bn["models"]["vgg_a_batchnorm"]
    lines = [
        "# Project 2 Report",
        "",
        "Name: Wang Sichen (please verify)",
        "Student ID: TODO",
        "",
        "## Summary",
        f"The final CIFAR-10 model is `gelu_label_smooth_adamw`, trained for {cifar_best['epochs']} epochs on all 50,000 training images. It achieves test accuracy {pct(cifar_best['best_test_accuracy'])} and test error {pct(cifar_best['best_test_error'])}.",
        "",
        "## Deliverable Links",
        "- Code: local `codes/` directory. Upload it to GitHub before final submission.",
        "- Dataset: local `cifar-10-batches-py/`; official dataset page https://www.cs.toronto.edu/~kriz/cifar.html.",
        f"- Best model weights: `{rel(best['weights'])}`. Upload this file to Netdisk/Google Drive before final submission.",
        "",
        "## CIFAR-10 Configuration Comparison",
        "| Model | Parameters | Activation | Loss | Optimizer | Best accuracy | Test error |",
        "| --- | ---: | --- | --- | --- | ---: | ---: |",
    ]
    for result in cifar_cmp["results"]:
        config = result["config"]
        lines.append(
            f"| {config['name']} | {result['parameters']:,} | {config['activation']} | "
            f"{config['loss']} | {config['optimizer']} | {pct(result['best_test_accuracy'])} | "
            f"{pct(result['best_test_error'])} |"
        )
    lines += [
        "",
        "## Batch Normalization Comparison",
        f"VGG-A without BN: best validation accuracy {pct(max(run['best_val_accuracy'] for run in bn_no['runs']))}.",
        f"VGG-A with BN: best validation accuracy {pct(max(run['best_val_accuracy'] for run in bn_yes['runs']))}.",
        f"Average gradient-spread proxy: VGG-A {grad_summary['VGG-A']['avg_spread']:.4f}, VGG-A + BN {grad_summary['VGG-A + BN']['avg_spread']:.4f}.",
    ]
    MD_PATH.write_text("\n".join(lines), encoding="utf-8")


def build_pdf(cifar_cmp, cifar_best, bn, gradient_figure, grad_summary):
    best = cifar_best["results"][0]
    with PdfPages(PDF_PATH) as pdf:
        writer = PdfWriter(pdf)
        writer.new_page()
        writer.heading("Project 2: Neural Network and Deep Learning", size=18)
        writer.paragraph("Name: Wang Sichen (please verify)")
        writer.paragraph("Student ID: TODO")
        writer.paragraph(
            "This report documents CIFAR-10 image-classification experiments and a "
            "Batch Normalization study using VGG-A. All reported numbers were obtained "
            "from local runs on the complete CIFAR-10 training and test splits unless "
            "a section explicitly states that a smaller subset was used."
        )
        writer.heading("Deliverable Links")
        writer.bullet("Code: local codes/ directory. Upload this directory to GitHub before final submission.")
        writer.bullet("Dataset: local cifar-10-batches-py/ directory; official dataset page https://www.cs.toronto.edu/~kriz/cifar.html.")
        writer.bullet(f"Best model weights: {rel(best['weights'])}. Upload this file to Netdisk or Google Drive before submission.")

        writer.heading("1. CIFAR-10 Network")
        writer.paragraph(
            "The final model is a compact convolutional network designed for 32x32 CIFAR-10 images. "
            "Each feature block contains two 2D convolutional layers, BatchNorm, an activation, "
            "2D max-pooling, and dropout. The classifier uses adaptive average pooling followed by "
            "fully connected layers. Thus the network explicitly includes fully connected layers, "
            "2D convolution, 2D pooling, nonlinear activations, BatchNorm, and dropout."
        )
        writer.paragraph(
            "Training used random crop with padding 4, horizontal flip, CIFAR-10 normalization, "
            "batch size 128, cosine learning-rate decay, and the RTX 3050 Laptop GPU."
        )
        writer.table(
            ["Experiment", "Params", "Activation", "Loss", "Optimizer", "Best acc.", "Test error"],
            [[
                result["config"]["name"],
                f"{result['parameters']:,}",
                result["config"]["activation"],
                result["config"]["loss"],
                result["config"]["optimizer"],
                pct(result["best_test_accuracy"]),
                pct(result["best_test_error"]),
            ] for result in cifar_cmp["results"]],
            col_widths=[0.25, 0.12, 0.11, 0.16, 0.13, 0.11, 0.12],
            font_size=7.5,
        )
        writer.paragraph(
            f"The strongest configuration was {cifar_best['best_model']}. After extending it to "
            f"{cifar_best['epochs']} epochs on all 50,000 training images, it reached test accuracy "
            f"{pct(cifar_best['best_test_accuracy'])}, so the best test error is "
            f"{pct(cifar_best['best_test_error'])}. The saved weight file is {rel(best['weights'])}."
        )
        writer.paragraph(
            "The comparison covers different filter counts (width 32 versus 48), different activations "
            "(ReLU versus GELU), different losses/regularization (plain cross entropy versus label "
            "smoothing with weight decay), and different optimizers from torch.optim (Adam, AdamW, "
            "and SGD with momentum)."
        )

        writer.image_page(
            "CIFAR-10 Training Curves",
            ROOT / cifar_cmp["training_curve_figure"],
            "Four-epoch comparison of candidate CNN configurations. Wider models and label smoothing "
            "improve the test curve; the final eight-epoch run of the best model is reported in the text.",
        )
        writer.image_page(
            "Learned First-Layer Filters",
            ROOT / cifar_best["filter_figure"],
            "Visualization of the first convolutional filters from the final best model. The filters "
            "learn color-opponent and edge-like patterns even in the compact network.",
        )

        writer.new_page()
        writer.heading("2. Batch Normalization Study")
        writer.paragraph(
            "For the BN task, VGG-A and VGG-A+BatchNorm were trained on a 10,000-image subset "
            "with a 2,000-image validation subset. This follows the project suggestion that a "
            "partial dataset may be used for faster BN analysis. The tested learning rates were "
            "1e-3, 2e-3, 5e-4, and 1e-4, using Adam and cross entropy for three epochs."
        )
        bn_rows = []
        for model_name, readable in [("vgg_a", "VGG-A"), ("vgg_a_batchnorm", "VGG-A + BN")]:
            for run in bn["models"][model_name]["runs"]:
                bn_rows.append([
                    readable,
                    f"{run['lr']:.0e}",
                    pct(run["best_val_accuracy"]),
                    pct(run["final_train_accuracy"]),
                    f"{run['final_train_loss']:.3f}",
                ])
        writer.table(
            ["Model", "LR", "Best val acc.", "Final train acc.", "Final train loss"],
            bn_rows,
            col_widths=[0.22, 0.12, 0.18, 0.18, 0.18],
            font_size=8,
        )
        writer.paragraph(
            "BN improves both stability and accuracy. The best VGG-A run without BN reached "
            f"{pct(max(run['best_val_accuracy'] for run in bn['models']['vgg_a']['runs']))}, "
            "whereas VGG-A+BN reached "
            f"{pct(max(run['best_val_accuracy'] for run in bn['models']['vgg_a_batchnorm']['runs']))}. "
            "At the aggressive learning rate 2e-3, the non-BN model was much less reliable, while "
            "the BN model still trained to a useful validation accuracy."
        )
        writer.paragraph(
            f"As a gradient-variation proxy, the average max-min spread of the tracked final-layer "
            f"gradient norm across learning rates was {grad_summary['VGG-A']['avg_spread']:.4f} for "
            f"VGG-A and {grad_summary['VGG-A + BN']['avg_spread']:.4f} for VGG-A+BN. The loss band "
            "and gradient plots together support the explanation that BN reparametrizes the problem "
            "into a smoother and less learning-rate-sensitive optimization landscape."
        )
        writer.image_page(
            "Loss Landscape Comparison",
            ROOT / bn["loss_landscape_figure"],
            "The filled band shows the min-max training loss across the four learning rates at each "
            "optimization step. BN produces a faster decrease and a narrower, more stable loss range.",
        )
        writer.image_page(
            "Gradient Variation Comparison",
            gradient_figure,
            "Gradient norm and max-min gradient spread across learning rates. This complements the "
            "loss landscape by showing how the update signal varies during optimization.",
        )

        writer.new_page()
        writer.heading("Conclusion")
        writer.paragraph(
            "The best CIFAR-10 model used a moderately wider CNN, GELU activations, BatchNorm, dropout, "
            "AdamW, weight decay, and label smoothing. It achieved 81.23% test accuracy after only "
            "eight epochs, corresponding to 18.77% test error. The ablations show that increasing "
            "filters and using a regularized loss improved generalization, while AdamW and SGD were "
            "both competitive."
        )
        writer.paragraph(
            "The VGG-A BN study shows the expected pattern: BN improves optimization stability, "
            "reduces sensitivity to learning-rate choice, and gives better validation accuracy in "
            "the same number of epochs. This matches the view that BN helps by smoothing the "
            "optimization landscape rather than merely reducing internal covariate shift."
        )
        writer.heading("References")
        writer.bullet("Krizhevsky and Hinton, Learning multiple layers of features from tiny images, 2009.")
        writer.bullet("Santurkar et al., How Does Batch Normalization Help Optimization?, NeurIPS 2018.")
        writer.bullet("Kingma and Ba, Adam: A Method for Stochastic Optimization, 2014.")
        writer.close()


def main():
    cifar_cmp = load_json(ROOT / "outputs" / "cifar_training" / "cifar_training_results.json")
    cifar_best = load_json(ROOT / "outputs" / "cifar_training_best" / "cifar_training_results.json")
    bn = load_json(ROOT / "outputs" / "bn_landscape" / "bn_landscape_results.json")
    gradient_figure, grad_summary = plot_gradient_variation()
    build_markdown(cifar_cmp, cifar_best, bn, grad_summary)
    build_pdf(cifar_cmp, cifar_best, bn, gradient_figure, grad_summary)
    print(PDF_PATH)
    print(MD_PATH)
    print(gradient_figure)


if __name__ == "__main__":
    main()
