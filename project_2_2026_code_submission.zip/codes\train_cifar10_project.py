"""Run the CIFAR-10 experiments for Project 2.

Example:
    d:\1\envs\AI\python.exe codes\train_cifar10_project.py --epochs 6
"""

import argparse
import json
import os
import random
from pathlib import Path

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms
from tqdm import tqdm


PROJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = PROJECT_ROOT / "outputs" / "cifar_training"
CIFAR_MEAN = (0.4914, 0.4822, 0.4465)
CIFAR_STD = (0.2470, 0.2435, 0.2616)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.benchmark = True


def get_device():
    return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def activation_layer(name):
    if name == "relu":
        return nn.ReLU(inplace=True)
    if name == "gelu":
        return nn.GELU()
    if name == "elu":
        return nn.ELU(inplace=True)
    raise ValueError(f"Unsupported activation: {name}")


class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, activation, dropout):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            activation_layer(activation),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            activation_layer(activation),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Dropout2d(dropout),
        )

    def forward(self, x):
        return self.net(x)


class CIFARCourseNet(nn.Module):
    """Compact CNN containing conv, pooling, activations, BN, dropout, and FC layers."""

    def __init__(self, width=48, activation="relu", dropout=0.25, num_classes=10):
        super().__init__()
        self.features = nn.Sequential(
            ConvBlock(3, width, activation, dropout * 0.5),
            ConvBlock(width, width * 2, activation, dropout),
            ConvBlock(width * 2, width * 4, activation, dropout),
        )
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(width * 4, 256),
            activation_layer(activation),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes),
        )

    def forward(self, x):
        return self.head(self.features(x))


def count_parameters(model):
    return sum(parameter.numel() for parameter in model.parameters())


def make_subset(dataset, n_items, seed):
    if n_items is None or n_items < 0 or n_items >= len(dataset):
        return dataset
    generator = torch.Generator().manual_seed(seed)
    indices = torch.randperm(len(dataset), generator=generator)[:n_items].tolist()
    return Subset(dataset, indices)


def get_loaders(batch_size, num_workers, train_items, val_items, seed):
    train_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(CIFAR_MEAN, CIFAR_STD),
    ])
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(CIFAR_MEAN, CIFAR_STD),
    ])

    train_dataset = datasets.CIFAR10(
        root=str(PROJECT_ROOT), train=True, download=False, transform=train_transform)
    test_dataset = datasets.CIFAR10(
        root=str(PROJECT_ROOT), train=False, download=False, transform=test_transform)
    train_dataset = make_subset(train_dataset, train_items, seed)
    test_dataset = make_subset(test_dataset, val_items, seed + 1)

    train_loader = DataLoader(
        train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers,
        pin_memory=torch.cuda.is_available())
    test_loader = DataLoader(
        test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers,
        pin_memory=torch.cuda.is_available())
    return train_loader, test_loader


def make_optimizer(config, model):
    if config["optimizer"] == "adam":
        return torch.optim.Adam(model.parameters(), lr=config["lr"],
                                weight_decay=config["weight_decay"])
    if config["optimizer"] == "adamw":
        return torch.optim.AdamW(model.parameters(), lr=config["lr"],
                                 weight_decay=config["weight_decay"])
    if config["optimizer"] == "sgd":
        return torch.optim.SGD(model.parameters(), lr=config["lr"], momentum=0.9,
                               nesterov=True, weight_decay=config["weight_decay"])
    raise ValueError(f"Unsupported optimizer: {config['optimizer']}")


def make_loss(config):
    if config["loss"] == "cross_entropy":
        return nn.CrossEntropyLoss()
    if config["loss"] == "label_smoothing":
        return nn.CrossEntropyLoss(label_smoothing=config.get("label_smoothing", 0.1))
    raise ValueError(f"Unsupported loss: {config['loss']}")


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    model.eval()
    total_loss = 0.0
    correct = 0
    total = 0
    for x, y in loader:
        x = x.to(device, non_blocking=True)
        y = y.to(device, non_blocking=True)
        logits = model(x)
        loss = criterion(logits, y)
        total_loss += float(loss.detach().cpu()) * y.numel()
        correct += (logits.argmax(dim=1) == y).sum().item()
        total += y.numel()
    return {
        "loss": total_loss / max(1, total),
        "accuracy": correct / max(1, total),
    }


def train_config(config, args, train_loader, test_loader, device):
    set_seed(args.seed)
    model = CIFARCourseNet(
        width=config["width"], activation=config["activation"], dropout=config["dropout"])
    model.to(device)
    criterion = make_loss(config)
    optimizer = make_optimizer(config, model)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

    history = []
    best_accuracy = 0.0
    best_epoch = 0
    weights_path = OUTPUT_ROOT / "models" / f"{config['name']}.pt"
    weights_path.parent.mkdir(parents=True, exist_ok=True)

    for epoch in tqdm(range(1, args.epochs + 1), desc=config["name"], leave=False):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        for x, y in train_loader:
            x = x.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            loss = criterion(logits, y)
            loss.backward()
            optimizer.step()

            running_loss += float(loss.detach().cpu()) * y.numel()
            correct += (logits.argmax(dim=1) == y).sum().item()
            total += y.numel()

        scheduler.step()
        test_metrics = evaluate(model, test_loader, criterion, device)
        epoch_record = {
            "epoch": epoch,
            "train_loss": running_loss / max(1, total),
            "train_accuracy": correct / max(1, total),
            "test_loss": test_metrics["loss"],
            "test_accuracy": test_metrics["accuracy"],
            "lr": scheduler.get_last_lr()[0],
        }
        history.append(epoch_record)

        if test_metrics["accuracy"] > best_accuracy:
            best_accuracy = test_metrics["accuracy"]
            best_epoch = epoch
            torch.save(model.state_dict(), weights_path)

    return {
        "config": config,
        "parameters": count_parameters(model),
        "best_test_accuracy": best_accuracy,
        "best_test_error": 1.0 - best_accuracy,
        "best_epoch": best_epoch,
        "weights": str(weights_path.relative_to(PROJECT_ROOT)),
        "history": history,
    }


def plot_training_curves(results, output_path):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for result in results:
        label = result["config"]["name"]
        epochs = [item["epoch"] for item in result["history"]]
        axes[0].plot(epochs, [item["test_accuracy"] for item in result["history"]],
                     marker="o", linewidth=1.4, label=label)
        axes[1].plot(epochs, [item["train_loss"] for item in result["history"]],
                     marker="o", linewidth=1.4, label=label)
    axes[0].set_title("Test accuracy")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Accuracy")
    axes[0].grid(alpha=0.25)
    axes[1].set_title("Training loss")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss")
    axes[1].grid(alpha=0.25)
    axes[1].legend(fontsize=7)
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=220)
    plt.close(fig)


def plot_first_layer_filters(best_result, output_path):
    model = CIFARCourseNet(
        width=best_result["config"]["width"],
        activation=best_result["config"]["activation"],
        dropout=best_result["config"]["dropout"],
    )
    state = torch.load(PROJECT_ROOT / best_result["weights"], map_location="cpu")
    model.load_state_dict(state)

    first_conv = next(module for module in model.modules() if isinstance(module, nn.Conv2d))
    weights = first_conv.weight.detach().cpu()
    filters_n = min(32, weights.shape[0])
    cols = 8
    rows = int(np.ceil(filters_n / cols))

    fig, axes = plt.subplots(rows, cols, figsize=(cols * 1.2, rows * 1.2))
    axes = np.asarray(axes).reshape(rows, cols)
    for idx in range(rows * cols):
        ax = axes[idx // cols, idx % cols]
        ax.axis("off")
        if idx >= filters_n:
            continue
        filt = weights[idx].permute(1, 2, 0).numpy()
        filt = (filt - filt.min()) / (filt.max() - filt.min() + 1e-8)
        ax.imshow(filt, interpolation="nearest")
    fig.suptitle("First-layer convolution filters", fontsize=12)
    fig.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=220)
    plt.close(fig)


def default_configs():
    return [
        {
            "name": "baseline_width32_relu_adam",
            "width": 32,
            "activation": "relu",
            "dropout": 0.15,
            "loss": "cross_entropy",
            "optimizer": "adam",
            "lr": 1e-3,
            "weight_decay": 5e-4,
        },
        {
            "name": "wider_width48_relu_adam",
            "width": 48,
            "activation": "relu",
            "dropout": 0.20,
            "loss": "cross_entropy",
            "optimizer": "adam",
            "lr": 1e-3,
            "weight_decay": 5e-4,
        },
        {
            "name": "gelu_label_smooth_adamw",
            "width": 48,
            "activation": "gelu",
            "dropout": 0.25,
            "loss": "label_smoothing",
            "label_smoothing": 0.1,
            "optimizer": "adamw",
            "lr": 1e-3,
            "weight_decay": 1e-3,
        },
        {
            "name": "relu_sgd_momentum",
            "width": 48,
            "activation": "relu",
            "dropout": 0.20,
            "loss": "cross_entropy",
            "optimizer": "sgd",
            "lr": 0.08,
            "weight_decay": 5e-4,
        },
    ]


def run(args):
    global OUTPUT_ROOT
    if args.output_dir:
        output_dir = Path(args.output_dir)
        OUTPUT_ROOT = output_dir if output_dir.is_absolute() else PROJECT_ROOT / output_dir

    set_seed(args.seed)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    train_loader, test_loader = get_loaders(
        args.batch_size, args.num_workers, args.train_items, args.val_items, args.seed)
    device = get_device()

    configs = default_configs()
    if args.only:
        requested = set(args.only)
        configs = [config for config in configs if config["name"] in requested]
        missing = requested - {config["name"] for config in configs}
        if missing:
            raise ValueError(f"Unknown config(s): {sorted(missing)}")
    if args.quick:
        configs = configs[:2]
        args.epochs = 1
        args.train_items = 512
        args.val_items = 256
        train_loader, test_loader = get_loaders(
            args.batch_size, args.num_workers, args.train_items, args.val_items, args.seed)

    results = []
    for config in configs:
        results.append(train_config(config, args, train_loader, test_loader, device))

    best_result = max(results, key=lambda item: item["best_test_accuracy"])
    training_curve_path = OUTPUT_ROOT / "training_curves.png"
    filters_path = OUTPUT_ROOT / "first_layer_filters.png"
    plot_training_curves(results, training_curve_path)
    plot_first_layer_filters(best_result, filters_path)

    summary = {
        "device": str(device),
        "train_items": len(train_loader.dataset),
        "test_items": len(test_loader.dataset),
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "best_model": best_result["config"]["name"],
        "best_test_accuracy": best_result["best_test_accuracy"],
        "best_test_error": best_result["best_test_error"],
        "training_curve_figure": str(training_curve_path.relative_to(PROJECT_ROOT)),
        "filter_figure": str(filters_path.relative_to(PROJECT_ROOT)),
        "results": results,
    }
    with (OUTPUT_ROOT / "cifar_training_results.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--train-items", type=int, default=-1)
    parser.add_argument("--val-items", type=int, default=-1)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--only", nargs="*", default=None,
                        help="Run only the named experiment configs.")
    parser.add_argument("--output-dir", default=None,
                        help="Override the output directory, relative to the project root by default.")
    parser.add_argument("--quick", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
