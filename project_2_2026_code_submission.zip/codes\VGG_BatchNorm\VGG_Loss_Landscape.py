"""Train VGG-A with/without BatchNorm and plot the loss landscape band.

The original course file contained several placeholders. This version keeps the
same experiment idea but makes it runnable from the project root:

    d:\1\envs\AI\python.exe codes\VGG_BatchNorm\VGG_Loss_Landscape.py --quick
"""

import argparse
import json
import os
import random
from pathlib import Path

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch import nn
from tqdm import tqdm

from data.loaders import get_cifar_loader
from models.vgg import VGG_A, VGG_A_BatchNorm, get_number_of_parameters


PROJECT_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_ROOT = PROJECT_ROOT / "outputs" / "bn_landscape"


def get_device():
    return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def set_random_seeds(seed_value=2020, device=None):
    np.random.seed(seed_value)
    torch.manual_seed(seed_value)
    random.seed(seed_value)
    if device is not None and device.type == "cuda":
        torch.cuda.manual_seed(seed_value)
        torch.cuda.manual_seed_all(seed_value)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


@torch.no_grad()
def get_accuracy(model, data_loader, device):
    model.eval()
    correct = 0
    total = 0
    for x, y in data_loader:
        x = x.to(device, non_blocking=True)
        y = y.to(device, non_blocking=True)
        prediction = model(x)
        correct += (prediction.argmax(dim=1) == y).sum().item()
        total += y.numel()
    return correct / total if total else 0.0


def train(model, optimizer, criterion, train_loader, val_loader, device, epochs_n=5,
          scheduler=None, best_model_path=None):
    model.to(device)
    history = {
        "train_loss_epoch": [],
        "train_accuracy": [],
        "val_accuracy": [],
        "batch_losses": [],
        "grad_norms": [],
    }
    best_val_accuracy = 0.0

    for epoch in tqdm(range(epochs_n), unit="epoch", leave=False):
        if scheduler is not None:
            scheduler.step()

        model.train()
        running_loss = 0.0
        correct = 0
        total = 0
        batch_losses = []
        grad_norms = []

        for x, y in train_loader:
            x = x.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)

            optimizer.zero_grad(set_to_none=True)
            prediction = model(x)
            loss = criterion(prediction, y)
            loss.backward()

            tracked_grad = None
            for parameter in reversed(list(model.parameters())):
                if parameter.grad is not None:
                    tracked_grad = parameter.grad.detach()
                    break
            if tracked_grad is not None:
                grad_norms.append(float(tracked_grad.norm().cpu()))

            optimizer.step()

            loss_value = float(loss.detach().cpu())
            batch_losses.append(loss_value)
            running_loss += loss_value
            correct += (prediction.argmax(dim=1) == y).sum().item()
            total += y.numel()

        train_accuracy = correct / total if total else 0.0
        val_accuracy = get_accuracy(model, val_loader, device)
        history["train_loss_epoch"].append(running_loss / max(1, len(train_loader)))
        history["train_accuracy"].append(train_accuracy)
        history["val_accuracy"].append(val_accuracy)
        history["batch_losses"].extend(batch_losses)
        history["grad_norms"].extend(grad_norms)

        if best_model_path is not None and val_accuracy > best_val_accuracy:
            best_val_accuracy = val_accuracy
            torch.save(model.state_dict(), best_model_path)

    return history


def min_max_curve(curves):
    min_len = min(len(curve) for curve in curves if len(curve) > 0)
    stacked = np.stack([np.asarray(curve[:min_len], dtype=np.float32) for curve in curves])
    return stacked.min(axis=0), stacked.max(axis=0), stacked.mean(axis=0)


def plot_loss_landscape(no_bn_curves, bn_curves, output_path):
    no_bn_min, no_bn_max, no_bn_mean = min_max_curve(no_bn_curves)
    bn_min, bn_max, bn_mean = min_max_curve(bn_curves)
    steps_no_bn = np.arange(len(no_bn_mean))
    steps_bn = np.arange(len(bn_mean))

    plt.figure(figsize=(9, 5))
    plt.fill_between(steps_no_bn, no_bn_min, no_bn_max, color="#d95f02", alpha=0.22,
                     label="VGG-A loss range")
    plt.plot(steps_no_bn, no_bn_mean, color="#d95f02", linewidth=1.6,
             label="VGG-A mean loss")
    plt.fill_between(steps_bn, bn_min, bn_max, color="#1b9e77", alpha=0.22,
                     label="VGG-A + BN loss range")
    plt.plot(steps_bn, bn_mean, color="#1b9e77", linewidth=1.6,
             label="VGG-A + BN mean loss")
    plt.xlabel("Optimization step")
    plt.ylabel("Training loss")
    plt.title("Loss landscape comparison across learning rates")
    plt.grid(alpha=0.25)
    plt.legend()
    plt.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_path, dpi=220)
    plt.close()


def run_experiment(args):
    device = get_device()
    set_random_seeds(args.seed, device)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    train_loader = get_cifar_loader(
        root=str(PROJECT_ROOT),
        batch_size=args.batch_size,
        train=True,
        shuffle=True,
        num_workers=args.num_workers,
        n_items=args.n_items,
        download=False,
    )
    val_loader = get_cifar_loader(
        root=str(PROJECT_ROOT),
        batch_size=args.batch_size,
        train=False,
        shuffle=False,
        num_workers=args.num_workers,
        n_items=args.val_items,
        download=False,
    )

    lrs = args.learning_rates
    criterion = nn.CrossEntropyLoss()
    results = {
        "device": str(device),
        "train_items": len(train_loader.dataset),
        "val_items": len(val_loader.dataset),
        "epochs": args.epochs,
        "learning_rates": lrs,
        "models": {},
    }

    for model_name, model_factory in (("vgg_a", VGG_A), ("vgg_a_batchnorm", VGG_A_BatchNorm)):
        curves = []
        results["models"][model_name] = {
            "parameters": get_number_of_parameters(model_factory()),
            "runs": [],
        }
        for lr in lrs:
            set_random_seeds(args.seed, device)
            model = model_factory()
            optimizer = torch.optim.Adam(model.parameters(), lr=lr)
            model_path = OUTPUT_ROOT / f"{model_name}_lr_{lr:g}.pt"
            history = train(
                model,
                optimizer,
                criterion,
                train_loader,
                val_loader,
                device,
                epochs_n=args.epochs,
                best_model_path=model_path,
            )
            curves.append(history["batch_losses"])
            run_summary = {
                "lr": lr,
                "final_train_loss": history["train_loss_epoch"][-1],
                "final_train_accuracy": history["train_accuracy"][-1],
                "final_val_accuracy": history["val_accuracy"][-1],
                "best_val_accuracy": max(history["val_accuracy"]),
                "weights": str(model_path.relative_to(PROJECT_ROOT)),
            }
            results["models"][model_name]["runs"].append(run_summary)
            np.savetxt(OUTPUT_ROOT / f"{model_name}_lr_{lr:g}_losses.txt",
                       np.asarray(history["batch_losses"]), fmt="%.8f")
            np.savetxt(OUTPUT_ROOT / f"{model_name}_lr_{lr:g}_grad_norms.txt",
                       np.asarray(history["grad_norms"]), fmt="%.8f")

        results["models"][model_name]["loss_min"], results["models"][model_name]["loss_max"], _ = [
            curve.tolist() for curve in min_max_curve(curves)
        ]
        results["models"][model_name]["curves_used"] = len(curves)

        if model_name == "vgg_a":
            no_bn_curves = curves
        else:
            bn_curves = curves

    figure_path = OUTPUT_ROOT / "loss_landscape_comparison.png"
    plot_loss_landscape(no_bn_curves, bn_curves, figure_path)
    results["loss_landscape_figure"] = str(figure_path.relative_to(PROJECT_ROOT))

    with (OUTPUT_ROOT / "bn_landscape_results.json").open("w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print(json.dumps(results, indent=2))


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--n-items", type=int, default=10000)
    parser.add_argument("--val-items", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=2020)
    parser.add_argument("--learning-rates", type=float, nargs="+",
                        default=[1e-3, 2e-3, 5e-4, 1e-4])
    parser.add_argument("--quick", action="store_true",
                        help="Use a tiny subset for a fast smoke test.")
    args = parser.parse_args()
    if args.quick:
        args.epochs = 1
        args.n_items = 512
        args.val_items = 256
        args.learning_rates = [1e-3, 5e-4]
    return args


if __name__ == "__main__":
    run_experiment(parse_args())
