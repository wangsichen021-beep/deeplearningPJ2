# Project 2 Code Package

This archive contains the source code needed to reproduce the CIFAR-10 and Batch Normalization experiments.

## Contents

- `codes/train_cifar10_project.py`: CIFAR-10 model comparison and best-model training.
- `codes/VGG_BatchNorm/VGG_Loss_Landscape.py`: VGG-A vs VGG-A+BatchNorm loss landscape experiment.
- `codes/VGG_BatchNorm/models/vgg.py`: VGG-A and VGG-A+BatchNorm model definitions.
- `codes/VGG_BatchNorm/data/loaders.py`: CIFAR-10 data loader.
- `generate_project_report.py`: regenerates the final report from experiment outputs.
- `outputs_summary/`: compact JSON summaries and figures used in the report.

## Data

Place the official CIFAR-10 Python dataset directory at the project root:

```text
cifar-10-batches-py/
```

The scripts use `download=False` by default and read this directory directly.

## Main Commands

```bash
python codes/train_cifar10_project.py --epochs 8 --only gelu_label_smooth_adamw --output-dir outputs/cifar_training_best
python codes/VGG_BatchNorm/VGG_Loss_Landscape.py --epochs 3 --n-items 10000 --val-items 2000
python generate_project_report.py
```

The experiments in the completed report were run with Python 3.11, PyTorch 2.11.0+cu128, torchvision 0.26.0+cu128, and an NVIDIA RTX 3050 Laptop GPU.

## Reported Best Result

- CIFAR-10 best test accuracy: 81.23%
- CIFAR-10 best test error: 18.77%
- Best weights file outside this code archive: `outputs/cifar_training_best/models/gelu_label_smooth_adamw.pt`
